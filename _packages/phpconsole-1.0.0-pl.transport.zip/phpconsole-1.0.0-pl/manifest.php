<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog for PhpConsole.

```
1.0.0-pl (20.02.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# PhpConsole

### PhpConsole for MODx Revolution 3. 
### Author: Vgrish <vgrish@gmail.com>
### [The author of the idea is Nikolai Lanets @Fi1osof](https://github.com/MODX-Club/modx-console)


#### Инструкция
Компонент позволяет выполнить php код в панели управления сайта. 
Доступ к консоли возможен sudo пользователям, либо пользователям с разрешением **phpconsole**.

[![](https://file.modx.pro/files/3/0/7/3074ec73e150388c2614d7f8480a1730s.jpg)](https://file.modx.pro/files/3/0/7/3074ec73e150388c2614d7f8480a1730.png)

Пример получения и вывода пользователя
```
<?php

if ($user = $modx->getObject(modUser::class, [\'sudo\' => 1])) {
    print_r($user->toArray()); // add info to result
    $modx->log(1, print_r($user->toArray() ,1)); // add info to log
}
```

На вкладке **Результат** будет выведен ассоциативный массив объекта **modUser**
```
Array
(
    [id] => 1
    [username] => s33228
    [password] => $2y$10$LrbNqj8iH9zO8XrDTp.6h/j.zBiItcQBOHr/XhnlvVm
    [cachepwd] => 
    [class_key] => MODX\\Revolution\\modUser
    [active] => 1
    [remote_key] => 
    [remote_data] => 
    [hash_class] => MODX\\Revolution\\Hashing\\modNative
    [salt] => 
    [primary_group] => 1
    [session_stale] => Array
        (
            [0] => mgr
            [1] => web
        )

    [sudo] => 1
    [createdon] => 2024-02-19 09:40:45
)
```

Компонент поддерживает инициализацию повторного выполнения кода, необходимо лишь задать переменную **$REEXECUTE**
```
if ($_SESSION[\'idx\'] < 10) {
    echo \'idx: \'. $_SESSION[\'idx\'];
    $_SESSION[\'idx\']++;
    
    $REEXECUTE = true; // set flag repeat request
}
else {
    echo \'idx: \'. $_SESSION[\'idx\'];
}
```

Доступна загрузка кода из списка файлов простым перетаскиванием необходимого файла на область редактирования.


#### Licence
```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.
Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'b8aab93042c5404e6e8eb02da5f68350',
      'native_key' => 'b8aab93042c5404e6e8eb02da5f68350',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/24cd2b852a159a56d9f684b76c15a5eb.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '1744fe638e5dadd33135b24cabd4c5f9',
      'native_key' => '1744fe638e5dadd33135b24cabd4c5f9',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/fdb6fa873c74c43124bc7076a856e35a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '72f7c3877df3fd6fd5df3de596a48f43',
      'native_key' => '72f7c3877df3fd6fd5df3de596a48f43',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/9193ed5a5c10e44b4a448b3d23deb2e8.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '0946332a655b534e942369a3073cb043',
      'native_key' => 'phpconsole',
      'filename' => 'MODX/Revolution/modNamespace/06de1bb46969570760fc309bcf560c03.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '0e110f1a506f181fa80774ed69d6c0ac',
      'native_key' => 'phpconsole',
      'filename' => 'MODX/Revolution/modMenu/ddccea15be1116dc39f8768b963a2e0b.vehicle',
      'namespace' => 'phpconsole',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '34e9bad61e167b0cded59a9d0b041598',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicy/74966a74a2d2c7c1ab0632410008226c.vehicle',
      'namespace' => 'phpconsole',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'a18e7217b2fd2752b6422ccb900d6597',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/012786a8d41b2c238685e4a24f5210de.vehicle',
      'namespace' => 'phpconsole',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '3dcf2ae25732e0f6b64ac661987736ca',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/88628e7d6cac2c326f99436bad943816.vehicle',
    ),
  ),
);