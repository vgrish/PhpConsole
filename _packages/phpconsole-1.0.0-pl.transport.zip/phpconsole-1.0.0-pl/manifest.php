<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog for PhpConsole.

```
1.0.0-pl (20.02.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# PhpConsole

### PhpConsole for MODx Revolution 3. 
### Author: Vgrish <vgrish@gmail.com>
### [The author of the idea is Nikolai Lanets @Fi1osof](https://github.com/MODX-Club/modx-console)


#### Инструкция
Компонент позволяет выполнить php код в панели управления сайта. 
Доступ к консоли возможен sudo пользователям, либо пользователям с разрешением **phpconsole**.

[![](https://file.modx.pro/files/3/0/7/3074ec73e150388c2614d7f8480a1730s.jpg)](https://file.modx.pro/files/3/0/7/3074ec73e150388c2614d7f8480a1730.png)

Пример получения и вывода пользователя
```
<?php

if ($user = $modx->getObject(modUser::class, [\'sudo\' => 1])) {
    print_r($user->toArray()); // add info to result
    $modx->log(1, print_r($user->toArray() ,1)); // add info to log
}
```

На вкладке **Результат** будет выведен ассоциативный массив объекта **modUser**
```
Array
(
    [id] => 1
    [username] => s33228
    [password] => $2y$10$LrbNqj8iH9zO8XrDTp.6h/j.zBiItcQBOHr/XhnlvVm
    [cachepwd] => 
    [class_key] => MODX\\Revolution\\modUser
    [active] => 1
    [remote_key] => 
    [remote_data] => 
    [hash_class] => MODX\\Revolution\\Hashing\\modNative
    [salt] => 
    [primary_group] => 1
    [session_stale] => Array
        (
            [0] => mgr
            [1] => web
        )

    [sudo] => 1
    [createdon] => 2024-02-19 09:40:45
)
```

Компонент поддерживает инициализацию повторного выполнения кода, необходимо лишь задать переменную **$REEXECUTE**
```
if ($_SESSION[\'idx\'] < 10) {
    echo \'idx: \'. $_SESSION[\'idx\'];
    $_SESSION[\'idx\']++;
    
    $REEXECUTE = true; // set flag repeat request
}
else {
    echo \'idx: \'. $_SESSION[\'idx\'];
}
```

Доступна загрузка кода из списка файлов простым перетаскиванием необходимого файла на область редактирования.


#### Licence
```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.
Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'f684f62e33530557c0cc3b7769348d4b',
      'native_key' => 'f684f62e33530557c0cc3b7769348d4b',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/5c0b1d7301e32cd86e744e8b62c4d3cd.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'b25179839c7bf7831cc0315062864426',
      'native_key' => 'b25179839c7bf7831cc0315062864426',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/5dc8b103085defcc350ff0d5aee2f2a2.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '2dbe63ae9be0636f15a7a350762be588',
      'native_key' => '2dbe63ae9be0636f15a7a350762be588',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/f4c01017b3ba7b6bd9b7f2560f7ce885.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '41c9485fe26653e0910605ce99bb3c19',
      'native_key' => 'phpconsole',
      'filename' => 'MODX/Revolution/modNamespace/d474432d505bb02d74fc1e93c18fb371.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'd2b530f5ee2b5c82d27712c2f647ca8c',
      'native_key' => 'phpconsole',
      'filename' => 'MODX/Revolution/modMenu/c6be711e1551d591cd92fc366e7d0e99.vehicle',
      'namespace' => 'phpconsole',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '4f72d2f1d5ab4207e7fa23af48c04b08',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicy/09a9e7242035e7440ebb3010668d30c3.vehicle',
      'namespace' => 'phpconsole',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'f1ca1e4bcd2901e19e6a83d7a6ff2fb7',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/bbfe35e42e9023cd7eb4a11be22c759f.vehicle',
      'namespace' => 'phpconsole',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'a41ef6db863f0e9cdf256c3e7fa2a5b1',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/21ebc4d7971c3c3bdfd0679b009503e3.vehicle',
    ),
  ),
);