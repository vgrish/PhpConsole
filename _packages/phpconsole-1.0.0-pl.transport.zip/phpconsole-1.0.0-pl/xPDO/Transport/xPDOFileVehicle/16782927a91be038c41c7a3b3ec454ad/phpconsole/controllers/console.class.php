<?php

require_once dirname(__DIR__,1) . '/src/Controllers/Console.php';

class PhpConsoleConsoleManagerController extends PhpConsole\Controllers\Console {

}