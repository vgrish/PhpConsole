<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'PhpConsole\\Model',
    'namespacePrefix' => 'PhpConsole',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOObject' => 
        array (
            0 => 'PhpConsole\\Model\\Code',
        ),
    ),
);