<?php

/**
 * @var \MODX\Revolution\modX $modx
 * @var array $namespace
 */

require_once __DIR__ . '/vendor/autoload.php';