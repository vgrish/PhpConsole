<?php

/** @var array $_lang */

$_lang = array_merge($_lang, [
    'area_phpconsole_main' => 'Основные',
]);

